"""Genera macos/AppIcon.icns y build/AppIcon.ico (opcional; ambos ya vienen incluidos).
Requiere Pillow solo en la máquina que lo genera:  pip install pillow"""
import os
from PIL import Image, ImageDraw

S = 1024
im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
bg = Image.new("RGBA", (S, S))
bd = ImageDraw.Draw(bg)
for y in range(S):
    t = y / S
    bd.line([(0, y), (S, y)], fill=(int(22 - 9 * t), int(40 - 23 * t), int(78 - 55 * t), 255))
mask = Image.new("L", (S, S), 0)
ImageDraw.Draw(mask).rounded_rectangle([100, 100, 924, 924], radius=185, fill=255)
im.paste(bg, (0, 0), mask)
d = ImageDraw.Draw(im)
x0, y0, x1, y1 = 230, 330, 794, 710
d.rounded_rectangle([x0, y0, x1, y1], radius=40, fill=(230, 237, 243, 255))
d.line([(x0 + 20, y0 + 25), (512, 560), (x1 - 20, y0 + 25)], fill=(47, 129, 247, 255), width=34, joint="curve")
cx, cy, r = 740, 700, 140
d.ellipse([cx - r - 14, cy - r - 14, cx + r + 14, cy + r + 14], fill=(13, 17, 23, 255))
d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=(63, 185, 80, 255))
d.line([(cx - 65, cy + 5), (cx - 15, cy + 55), (cx + 70, cy - 50)], fill="white", width=34, joint="curve")
out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "AppIcon.icns")
im.save(out, sizes=[(16, 16), (32, 32), (64, 64), (128, 128), (256, 256), (512, 512), (1024, 1024)])
print("Generado:", out)
ico = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "build", "AppIcon.ico")
im.save(ico, sizes=[(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)])
print("Generado:", ico)
