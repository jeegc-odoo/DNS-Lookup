#!/usr/bin/env bash
# Arma "Mail Diagnostics.app" y su .zip a partir del código fuente.
# Uso:  ./macos/build_app.sh        (funciona en macOS o Linux; no compila nada,
#                                    solo copia archivos de texto a la estructura .app)
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
DIST="$ROOT/dist"
APP="$DIST/Mail Diagnostics.app"

rm -rf "$APP"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
cp "$ROOT/macos/Info.plist"          "$APP/Contents/Info.plist"
cp "$ROOT/macos/MailDiagnostics"     "$APP/Contents/MacOS/MailDiagnostics"
cp "$ROOT/macos/AppIcon.icns"        "$APP/Contents/Resources/AppIcon.icns"
cp "$ROOT/app/mail_diagnostics.py"   "$APP/Contents/Resources/mail_diagnostics.py"
cp "$ROOT/app/requirements.txt"      "$APP/Contents/Resources/requirements.txt"
chmod 755 "$APP/Contents/MacOS/MailDiagnostics"
chmod 644 "$APP/Contents/Info.plist" "$APP/Contents/Resources/"*

# Huellas de todo lo que va dentro de la app, para poder auditar la versión distribuida
( cd "$APP/Contents" && find . -type f ! -name SHA256SUMS -print0 | sort -z \
    | xargs -0 shasum -a 256 2>/dev/null || find . -type f ! -name SHA256SUMS -print0 | sort -z | xargs -0 sha256sum ) \
    > "$DIST/SHA256SUMS-app.txt"

( cd "$DIST" && rm -f Mail_Diagnostics_Mac.zip && zip -qr -X Mail_Diagnostics_Mac.zip "Mail Diagnostics.app" )
echo "Listo: $DIST/Mail_Diagnostics_Mac.zip"
echo "Huellas: $DIST/SHA256SUMS-app.txt"
