# Mail Diagnostics 2.2 — Privacidad y flujo de datos

Resumen para auditoría. El detalle línea por línea está en
**Memoria_Tecnica_Mail_Diagnostics_2.2.pdf**.

## Resumen

- **Sin telemetría**, sin analíticas, sin reportes de errores remotos, sin actualizaciones automáticas.
- **Ningún servicio de terceros**: la app solo se conecta a los dominios, hosts y puertos que escribe el usuario, y usa solo el DNS del sistema.
- **La versión compilada no descarga nada**: lleva Python, Tk, OpenSSL y dnspython dentro.
- **Nada se instala sin permiso**: la única instalación posible de la versión compilada es `ping` en Linux, si falta, tras un “Sí” y la contraseña de administrador. Los launchers del código fuente tampoco descargan nada sin un “sí” explícito.
- **Una sola dependencia externa** (`dnspython 2.7.0`), con versión fija y huella SHA-256. Las herramientas de compilación también están fijadas por huella.
- **Credenciales SMTP**: nunca se guardan; solo se envían dentro de TLS 1.2+ con certificado verificado.
- **Sin datos del equipo**: ni el saludo SMTP, ni la ventana, ni el log, ni el PDF incluyen el nombre del equipo.

## 1. Conexiones de red

| Origen | Cuándo | Destino | Qué se envía |
|---|---|---|---|
| App: DNS | Prueba DNS o modo MX | Resolvedor DNS del sistema (nunca otro) | Consultas de los dominios escritos, `_dmarc.`, `<selector>._domainkey.`, `www.` |
| App: Telnet | Prueba Telnet | Hosts y puertos elegidos | `EHLO [IP-local]`, `QUIT` |
| App: TLS | Prueba TLS | Hosts y puertos elegidos | Handshake TLS (SNI), `EHLO [IP-local]`, `STARTTLS`, credenciales solo con certificado verificado y TLS 1.2+, `QUIT` |
| App: Ping | Prueba Ping | Hosts elegidos | Paquetes ICMP |
| App (Linux) | Solo si falta `ping` y el usuario acepta | Repositorios de la distribución | Lo que envía el gestor de paquetes al instalar `iputils` |
| Launcher Mac (código fuente) | Solo si falta Python, con permiso | www.python.org | Descarga del instalador (firma verificada) |
| Launchers (código fuente) | Solo si falta dnspython, con permiso | pypi.org | Descarga de dnspython (huella verificada). El User-Agent de pip incluye versión de Python, SO y OpenSSL |
| Compilación | Solo en la máquina que compila | pypi.org, github.com | Herramientas y Python de Linux (huellas verificadas) |

Las únicas llamadas de red de la app están en `app/mail_diagnostics.py`:
`socket.create_connection` (l. 1121 y 1207), `self.resolver.resolve` (l. 989, 1013 y 1024)
y el comando `ping` (l. 1411).

## 2. Credenciales SMTP

- Viven solo en memoria; nunca se escriben en disco, log, portapapeles ni PDF.
- Base64 no es cifrado: lo que las protege es el túnel TLS.
- No se envían si el certificado no se verificó (o el usuario desmarcó la verificación) ni si la sesión es TLS 1.0/1.1.
- El **nombre de usuario sí aparece** en el log y el PDF.

## 3. Archivos que se escriben

| Archivo | Contenido | Ubicación |
|---|---|---|
| Reportes PDF | Log de la corrida (dominios, IPs, respuestas, certificados, fecha, versión). Sin contraseña, sin datos del equipo, sin metadatos | `Documentos/Mail Diagnostics/reportes` (compilada y app ligera de Mac); junto al script en Linux desde fuente |
| `selfcheck.ok` | Solo el número de versión (compilada) | macOS `~/Library/Application Support/Mail Diagnostics`; Windows `%APPDATA%\Mail Diagnostics`; Linux `~/.config/Mail Diagnostics` |
| Temporal `.pem` | Certificado público de un servidor no verificado; se borra de inmediato | Carpeta temporal |
| `launcher.log` (app ligera de Mac) | Pasos del launcher, salida de pip, errores de la app | `~/Library/Logs/Mail Diagnostics` (700) |
| Entorno de Python (código fuente) | dnspython | `~/Library/Application Support/Mail Diagnostics/venv` o `linux/dns_env` |

El portapapeles solo se usa al pulsar “Copiar log”.

## 4. Correcciones de la versión 2.2

1. Ya no se usan los DNS públicos de Cloudflare/Google si el sistema no tiene DNS configurado.
2. Los nombres de servidor obtenidos por DNS (modo MX) se validan antes de usarse en `ping`.
3. No se envían credenciales por TLS 1.0/1.1.
4. Se quitó el nombre del equipo de la ventana, el reporte y el PDF, y la versión de macOS del registro.
5. `pkexec` y el gestor de paquetes se buscan solo en carpetas del sistema, nunca en el PATH del usuario.
6. Abrir el script sin dnspython muestra un aviso; la app nunca instala nada por sí misma salvo `ping` con permiso.

## 5. Límites conocidos

- Ejecutables sin firma de desarrollador (Gatekeeper y SmartScreen avisarán la primera vez).
- PyInstaller no garantiza compilaciones idénticas byte a byte; cada paquete trae las huellas de su contenido.
- En macOS se confía en todos los certificados del llavero del sistema (incluidos los corporativos).
- Las consultas DNS viajan sin cifrar, como las de cualquier programa del equipo.
- Python no permite borrar una cadena de la memoria de forma segura; la contraseña queda en el campo hasta cerrar la app.
