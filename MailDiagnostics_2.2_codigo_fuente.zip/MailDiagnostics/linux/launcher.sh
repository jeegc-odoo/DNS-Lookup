#!/usr/bin/env bash
# =============================================================================
#  Mail Diagnostics - launcher para Linux (también funciona en macOS desde Terminal)
#
#  En el primer arranque (o si falta algo) revisa los componentes, muestra qué
#  encontró y NO descarga ni instala nada sin permiso del usuario.
#  La única descarga posible es dnspython 2.7.0 desde pypi.org, verificada con
#  su huella SHA-256 (requirements.txt). Python y Tkinter se instalan con el
#  gestor de paquetes del sistema: este script solo indica el comando.
# =============================================================================

set -u
APP_VERSION="2.2"
DEP_NAME="dnspython"
DEP_VERSION="2.7.0"

if [ -t 1 ]; then
    G=$'\033[32m'; R=$'\033[31m'; Y=$'\033[33m'; B=$'\033[36m'; N=$'\033[0m'
else
    G=""; R=""; Y=""; B=""; N=""
fi
info() { echo "${B}[*]${N} $*"; }
ok()   { echo "${G}[OK]${N} $*"; }
bad()  { echo "${R}[X]${N} $*"; }
warn() { echo "${Y}[!]${N} $*"; }
fail() { bad "$*"; exit 1; }

HERE="$(cd "$(dirname "$0")" && pwd)"
# Busca la app junto al launcher, o en ../app (estructura del código fuente)
if [ -f "$HERE/mail_diagnostics.py" ]; then APP_DIR="$HERE"; else APP_DIR="$HERE/../app"; fi
APP_SCRIPT="$APP_DIR/mail_diagnostics.py"
REQS="$APP_DIR/requirements.txt"
VENV="$HERE/dns_env"
VPY="$VENV/bin/python"
STAMP="$VENV/.setup_ok"

[ -f "$APP_SCRIPT" ] && [ -f "$REQS" ] || fail "No encuentro mail_diagnostics.py y requirements.txt (busqué en $APP_DIR)."

# Gestor de paquetes, para indicar el comando correcto
OS="$(uname -s)"
if [ "$OS" = "Darwin" ]; then PKG_MGR="brew"
elif command -v apt-get >/dev/null 2>&1; then PKG_MGR="apt"
elif command -v dnf >/dev/null 2>&1; then PKG_MGR="dnf"
elif command -v pacman >/dev/null 2>&1; then PKG_MGR="pacman"
else PKG_MGR="unknown"; fi
hint() {   # $1 apt, $2 dnf, $3 pacman, $4 brew
    case "$PKG_MGR" in
        apt)    echo "      sudo apt install $1" ;;
        dnf)    echo "      sudo dnf install $2" ;;
        pacman) echo "      sudo pacman -S $3" ;;
        brew)   echo "      brew install $4" ;;
        *)      echo "      Instala '$1' con el gestor de paquetes de tu sistema." ;;
    esac
}

echo
info "Mail Diagnostics $APP_VERSION — revisión de componentes"
echo

# ---------------------------------------------- Requisitos del sistema ------
# Estos no se instalan solos: requieren permisos de administrador y el gestor
# de paquetes del sistema, así que solo se indica el comando.
command -v python3 >/dev/null 2>&1 || { bad "Python 3 no está instalado. Instálalo con:"; hint python3 python3 python python; exit 1; }
python3 -I -c 'import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)' \
    || fail "Se necesita Python 3.9 o superior (tienes $(python3 -V 2>&1))."
ok "$(python3 -V 2>&1)"
PYV="$(python3 -I -c 'import sys; print(f"{sys.version_info[0]}.{sys.version_info[1]}")')"

if ! python3 -I -c 'import tkinter' >/dev/null 2>&1; then
    bad "Falta Tkinter (la librería de la interfaz gráfica). Instálalo con:"
    hint python3-tk python3-tkinter tk "python-tk@$PYV"
    exit 1
fi
ok "Tkinter $(python3 -I -c 'import tkinter; print(tkinter.TkVersion)')"

python3 -I -c 'import ssl' >/dev/null 2>&1 || fail "Este Python no tiene soporte SSL."
ok "SSL: $(python3 -I -c 'import ssl; print(ssl.OPENSSL_VERSION)')"

python3 -I -c 'import venv, ensurepip' >/dev/null 2>&1 || {
    bad "Falta el módulo venv de Python. Instálalo con:"
    hint "python$PYV-venv" python3 python python3
    exit 1
}

command -v ping >/dev/null 2>&1 && ok "ping disponible" \
    || warn "No se encontró 'ping'; la prueba de Ping no funcionará."

# --------------------------------------------- Dependencia de Python ------
deps_ok() {
    [ -x "$VPY" ] && "$VPY" -I -c "import dns.resolver, dns.version, sys
sys.exit(0 if dns.version.version == '$DEP_VERSION' else 1)" >/dev/null 2>&1
}

if deps_ok; then
    ok "$DEP_NAME $DEP_VERSION"
else
    bad "$DEP_NAME $DEP_VERSION: falta"
    echo
    echo "  Para continuar, con tu permiso se hará lo siguiente:"
    echo "   • Crear un entorno privado de Python en: $VENV"
    echo "   • Descargar $DEP_NAME $DEP_VERSION desde pypi.org (unos 310 KB),"
    echo "     comprobar su huella SHA-256 e instalarlo solo en ese entorno."
    echo "  No se envía ninguna información tuya ni se modifica el sistema."
    echo
    if [ ! -t 0 ]; then
        fail "Se necesita tu confirmación: ejecuta este launcher desde una terminal."
    fi
    read -r -p "  ¿Das permiso para instalarlo? [s/N] " RESP
    case "$RESP" in
        s|S|si|SI|sí|Sí|y|Y) ;;
        *) echo; warn "No se instaló nada."; exit 0 ;;
    esac

    info "Creando entorno privado..."
    rm -rf "$VENV"
    python3 -m venv "$VENV" || fail "No se pudo crear el entorno virtual."
    info "Descargando e instalando $DEP_NAME $DEP_VERSION (verificado por huella)..."
    "$VPY" -I -m pip install --isolated --no-input --disable-pip-version-check --quiet \
        --index-url https://pypi.org/simple --require-hashes --only-binary=:all: --no-deps \
        -r "$REQS"
    if ! deps_ok; then
        rm -rf "$VENV"
        fail "No se pudo instalar $DEP_NAME (sin conexión, o el archivo no coincidió con su huella). No se dejó nada a medias."
    fi
    ok "$DEP_NAME $DEP_VERSION instalado y verificado"
fi

if [ "$(cat "$STAMP" 2>/dev/null)" != "$APP_VERSION" ]; then
    echo "$APP_VERSION" >"$STAMP"
    echo
    ok "Revisión inicial completa: todos los componentes están instalados."
fi

# ------------------------------------------------------------ Lanzar ------
if [ "$OS" = "Linux" ] && [ -z "${DISPLAY:-}" ] && [ -z "${WAYLAND_DISPLAY:-}" ]; then
    fail "No hay pantalla gráfica disponible (¿estás en SSH sin -X?)."
fi

info "Abriendo la interfaz..."
echo
# -I: modo aislado (ignora PYTHONPATH y otras variables que podrían inyectar código)
"$VPY" -I "$APP_SCRIPT" "$@"
STATUS=$?
[ $STATUS -eq 0 ] || warn "La aplicación terminó con código $STATUS."
exit $STATUS
