# Mail Diagnostics 2.2 — código fuente

Herramienta de diagnóstico de correo: DNS (MX, SPF, DMARC, DKIM), Telnet/SMTP,
TLS/OpenSSL con autenticación, y Ping. Interfaz gráfica en Tkinter.

- **SEGURIDAD.md**: resumen de privacidad y flujo de datos.
- **Memoria_Tecnica_Mail_Diagnostics_2.2.pdf**: explicación de cada línea de cada archivo.

## Atajos de teclado

| Tecla | Acción |
|---|---|
| F5 o Ctrl+Enter | Ejecutar todas las pruebas marcadas |
| F6 | Solo DNS |
| F7 | Solo Telnet |
| F8 | Solo TLS/OpenSSL |
| F9 | Solo Ping |

En una Mac portátil, las teclas de función se pulsan junto con `fn`, salvo que en Ajustes
del Sistema → Teclado estén configuradas como teclas de función estándar.

## Estructura

```
app/
  mail_diagnostics.py        La aplicación completa (un solo archivo)
  requirements.txt           dnspython 2.7.0 con huella (para ejecutar desde el código fuente)
build/                       Compilación (versión recomendada)
  mail_diagnostics.spec      Receta de PyInstaller para los tres sistemas
  build.sh                   Compilar en macOS o Linux
  build_windows.ps1          Compilar en Windows
  get_python_linux.sh        Descarga verificada del Python para compilar en Linux
  requirements-build.in/.txt Herramientas de compilación fijadas por versión y huella
  AppIcon.ico                Ícono de Windows
.github/workflows/
  compilar.yml               Compilación automática en GitHub (macOS, Windows, Linux)
macos/                       App ligera de Mac (sin Python dentro) e íconos
  MailDiagnostics            Launcher (bash)
  Info.plist, AppIcon.icns, make_icon.py, build_app.sh
linux/
  launcher.sh                Ejecutar desde el código fuente en Linux
```

## Versión compilada (recomendada)

Lleva Python, Tk, OpenSSL y dnspython dentro: no hay que instalar nada. En el primer
arranque revisa sus componentes y muestra el resultado; si en Linux falta `ping`, ofrece
instalarlo y solo lo hace si el usuario acepta (el sistema pide la contraseña de
administrador). El botón “Componentes” repite la revisión.

### Compilar en GitHub (los tres sistemas)

1. Subir esta carpeta a un repositorio de GitHub.
2. Pestaña **Actions** → **Compilar Mail Diagnostics** → **Run workflow**
   (o publicar una etiqueta como `v2.2`).
3. Al terminar, descargar los resultados de la ejecución: un paquete por sistema
   (macOS Apple Silicon, macOS Intel, Windows, Linux) con sus listas de huellas.

### Compilar a mano

Cada sistema solo puede compilar su propio ejecutable.

```
# macOS (Python 3.12 de python.org o Homebrew, con Tkinter)
PYTHON=$(which python3.12) ./build/build.sh

# Linux
PYTHON="$(./build/get_python_linux.sh)" ./build/build.sh

# Windows (PowerShell, con Python 3.12 instalado)
powershell -ExecutionPolicy Bypass -File build\build_windows.ps1
```

El resultado queda en `dist-compilado/`: el paquete (`.zip` o `.tar.gz`), su huella
(`*.sha256`) y la huella de cada archivo que contiene (`contenido_*.sha256`).

### Primera apertura

Los ejecutables no están firmados con un certificado de desarrollador:

- **macOS**: la primera vez, Ajustes del Sistema → Privacidad y seguridad → “Abrir de todos modos”.
- **Windows**: en el aviso de SmartScreen, “Más información” → “Ejecutar de todas formas”.
- **Linux**: descomprimir y ejecutar `MailDiagnostics/MailDiagnostics`. Requiere sesión gráfica.

Los PDF se guardan en `Documentos/Mail Diagnostics/reportes`.

## Ejecutar desde el código fuente

- macOS: `./macos/build_app.sh` arma una app ligera cuyo launcher revisa los componentes y
  pide permiso antes de instalar Python o dnspython.
- Linux: `sudo apt install python3-tk python3-venv` (o equivalente) y `./linux/launcher.sh`.

## Auditar la dependencia

```
pip download --no-deps --only-binary=:all: dnspython==2.7.0 -d /tmp/dl
shasum -a 256 /tmp/dl/dnspython-2.7.0-py3-none-any.whl
# debe dar b4c34b7d10b51bcc3a5071e7b8dee77939f1e878477eeecc965e9835f63c6c86
```
